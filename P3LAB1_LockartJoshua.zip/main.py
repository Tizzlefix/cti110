R = int(input())
G = int(input())
B = int(input())

m = min(R,G,B)

R-=m
G-=m
B-=m

print(R,G,B)