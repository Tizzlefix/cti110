user_int = int(input('Enter integer (32 - 126):\n'))

float_variable = float(input('Enter float:\n'))

char_variable = input('Enter character:\n')[0]

string_variable = input('Enter string:\n')

print(user_int, float_variable, char_variable, string_variable)
print(string_variable, char_variable, float_variable, user_int)
character=chr(user_int)
print(user_int, 'converted to a character is', character)