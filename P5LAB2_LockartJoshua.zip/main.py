def feet_to_steps(x):
    return int(x / 2.5) 

if __name__ == '__main__':
    x = float(input())

    print(feet_to_steps(x))