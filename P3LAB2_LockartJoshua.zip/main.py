service_choice = input('Enter desired auto service:\n')
print('You entered:', service_choice)

if service_choice == 'Oil change' :
    print('Cost of oil change: $35')
    
elif service_choice == 'Tire rotation' :
    print('Cost of tire rotation: $19')
    
elif service_choice == 'Car wash' :
    print('Cost of car wash: $7')
    
else:
    print('Error: Requested service is not recognized')